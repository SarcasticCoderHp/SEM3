#include<iostream>
using namespace std;

int main()
{
    string str;
    cout<<"Enter string value:";getline(cin,str);
    cout<<"Length of string:"<<str.length();
    return 0;
}