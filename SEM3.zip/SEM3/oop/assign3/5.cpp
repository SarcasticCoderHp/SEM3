#include<iostream>
using namespace std;

int main()
{
    int size=10;
    int a[size];

    cout<<"Enter 10 array elements";
    for(int i=0;i<size;i++)
    {
        cin>>a[i];
    }
    int large=a[0];
    int small=a[0];

    for(int i=1;i<size;i++)
    {
        if(a[i]>large)
        {
          large=a[i];
        }
        else if(a[i]<small)
        {
            small=a[i];
        }
    }
    cout<<"Largest number is:"<<large<<endl;
    cout<<"Smallest number is:"<<small;

    return 0;
}