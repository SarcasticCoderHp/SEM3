#include<iostream>
using namespace std;

int main()
{
    string sentance;

    cout<<"Enter a sentance:";
    getline(cin,sentance);

    int Words=0;
    int Char=0;

    for(char c:sentance)
    {
        if(c!=' ')
        {
            Char++;
        }
        else
        {
            Words++;
        }
    }
    Words++;

    cout<<"Number of words:"<<Words<<endl;
    cout<<"Number of characters:"<<Char;

    return 0;
}