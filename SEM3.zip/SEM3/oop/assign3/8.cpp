#include<iostream>
using namespace std;

int main()
{
    int r,c;

    cout<<"Enter rows and columns:";cin>>r>>c;

    int matrix1[r][c],matrix2[r][c],result[r][c];

    cout<<"Enter elements for first matrix:";
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Enter elements for second matrix:\n";
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cin>>matrix2[i][j];
        }
    }
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            result[i][j]=matrix1[i][j]+matrix2[i][j];
        }
    }
    cout<<"Addition of matrix is:\n";
    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<result[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}