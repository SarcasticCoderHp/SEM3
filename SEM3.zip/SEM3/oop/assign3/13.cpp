#include<iostream>
using namespace std;

int main()
{
     string str1;

    cout<<"Enter string 1:";
    getline(cin,str1);

    str1.resize(5);

    cout<<"Resized string is:"<<str1;

    return 0;
}