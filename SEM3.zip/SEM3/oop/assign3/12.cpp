#include<iostream>
using namespace std;

int main()
{
    string str1,str2;
    int choice;

    cout<<"Enter string 1:";
    getline(cin,str1);

    cout<<"Enter string 2:";
    getline(cin,str2);

    cout<<"1.Compare two strings.."<<endl;
    cout<<"2.Concate two strings.."<<endl;
    cout<<"3.Copy string.."<<endl;

    cout<<"Enter a choice:";cin>>choice;



    if(choice==1)
    {
        if(str1==str2)
    {
        cout<<"Equal strings";
    }
    else
    {
        cout<<"Not equal strings";
    }
    }
     
    else if(choice==2)
    {
        str1.append(str2);
        cout<<"Concated string is:"<<str1;
    }

    else if(choice==3)
    {
        char newstr[10];
  
        str1.copy(newstr,9,6);

        cout<<"Copied string is:"<<newstr<<endl;
    }

    else
    {
        cout<<"Error.....";
    }

    return 0;
}