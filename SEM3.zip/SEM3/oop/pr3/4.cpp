#include <iostream>
using namespace std;

class Average {
public:
    float num1, num2, num3;

    void input() {
        cout << "Enter three numbers: ";
        cin >> num1 >> num2 >> num3;
    }
    float findAverage() {
        return (num1 + num2 + num3) / 3;
    }

    void display(float avg) {
        cout << "Average: " << avg << endl;
    }
};

int main() {
    Average obj;
    obj.input();
    float average = obj.findAverage();
    obj.display(average);
    return 0;
}
