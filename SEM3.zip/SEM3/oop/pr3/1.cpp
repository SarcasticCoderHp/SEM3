#include<iostream>
using namespace std;

int main()
{
	int choice;

	cout<<"1.Sum of digits"<<endl;
	cout<<"2.Multiply of digits"<<endl;
	cout<<"3.Armstrong or not"<<endl;
	cout<<"4.Palindrome or not"<<endl;
	
	cout<<"Enter a choice:";cin>>choice;

        if(choice==1)
        {  
		int r,n;
		int sum=0;

		cout<<"Enter a number";cin>>n;

		while(n!=0)
		{
			r=n%10;
			sum=sum+r;
			n=n/10;
		}
		cout<<"Sum of digits is:"<<sum;
        }

		else if(choice==2)
		{
		int m=1,num,r;

		cout<<"Enter a number:";cin>>num;

		while(num!=0)
		{
			r=num%10;
			m=m*r;
			num=num/10;
		}
		cout<<"Multiply of digits is:"<<m;
        }

        else if(choice==3)
        {
            
         int num,r,sum=0,temp;

           cout<<"Enter a number:";
           cin>>num;

            temp=num;
 while(num!=0)
 {
            r=num%10;
            sum=sum+(r*r*r);
            num=num/10;
  }      
          
            if(temp==sum)
            {
            	cout<<"Armstrong number";
            }
            else
            {
            	 cout<<"Not Armstrong number";
            }
        }

        else if(choice==4)
        {
               int num,r,sum=0,temp;

           cout<<"Enter a number:";
           cin>>num;

            temp=num;
 while(num!=0)
 {
            r=num%10;
            sum=(sum*10)+r;
            num=num/10;
  }      
          
            if(temp==sum)
            {
            	cout<<"Palindrome number";
            }
            else
            {
            	 cout<<"Not Palindrome number";
            }
        }
        else{cout<<"Invalid choice";
}
return 0;
           
 } 
      

