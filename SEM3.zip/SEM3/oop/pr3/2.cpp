#include <iostream>
using namespace std;

int is_prime(int number) {
    if (number <= 1)
        return false;

    for (int i = 2; i < number; ++i) {
        if (number % i == 0)
            return false;
    }

    return true;
}

int main() {
    int start,end;
    cout << "Enter start range: ";
    cin >> start;
    cout << "Enter end range: ";
    cin >> end;

    cout << "Prime numbers: " << start << " and " << end << " are: ";
    for (int i = start; i <= end; ++i) {
        if (is_prime(i))
            cout << i << " ";
    }

   cout<<endl;
    return 0;
}
