#include<iostream>
using namespace std;

class Student
{
public:
    string name;
    int roll_no;
};
int main()
{
	Student obj;
	obj.name="John";
	obj.roll_no=2;

	cout<<"Name of student is:"<<obj.name<<endl;
	cout<<"Roll no of student is:"<<obj.roll_no;

	return 0;
}