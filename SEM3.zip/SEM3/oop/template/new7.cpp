#include<iostream>
using namespace std;

template<class T>

void show(T a,T b)
{
    cout<<endl<<a<<" "<<b<<endl;
}
int main()
{
    show(20,30);
    show(2.5,3.5);
    show('a','b');

    return 0;
}