#include<iostream>
using namespace std;

class Student
{
    private:

    int rollno;

    public:

    void get()
    {
        cout<<"Enter rollno:";cin>>rollno;
    }
    void display()
    {
        cout<<"Rollno is:"<<rollno<<endl;
    }
};
int main()
{
    Student *s=new Student;
    s->get();
    s->display();

    int n;
    cout<<"Enter no of students:";cin>>n;

    Student *s1=new Student[n];

    for(int i=0;i<3;i++)
    
        s[i].get();
    
    for(int i=0;i<3;i++)
    
        s[i].display();
    
    delete s;
    delete s1;
}