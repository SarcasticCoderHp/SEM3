#include<iostream>
using namespace std;

template<class T>

void show(T a,T b)
{
    cout<<"In template"<<endl;
    cout<<endl<<a<<" "<<b<<endl;
}

void show(int a,int b)
{
    cout<<"In function"<<endl;
    cout<<endl<<a<<" "<<b<<endl;
}

int main()
{
    show(20,30);  //F
    show(2.2,3.3); //T
    show(2,3);      //F
    show('A','B');   //T

    return 0;
}