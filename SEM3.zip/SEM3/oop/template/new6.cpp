#include<iostream>
using namespace std;

template<class T,class U>
class x
{
    public:
    T a;
    U b;

    void get();
    void display();
};

template<class T,class U>
void x<T,U>::get()
{
    cout<<"Enter value of a:";cin>>a;
    cout<<"Enter value of b:";cin>>b;
}

template<class T,class U>
void x<T,U>::display()
{
   cout<<endl<<a<<" "<<b<<endl;
}

int main()
{
    x<int,float>x1;
    x1.get();
    x1.display();

    x<float,char>x2;
    x2.get();
    x2.display();

    x<float,int>x3;
    x3.get();
    x3.display();

    return 0;
}