#include<iostream>
using namespace std;

template<class T>T add(T a,T b)
{
    T result=a+b;
    return result;
}

int main()
{
    int i=2;int j=3;
    float n=1.2;float m=1.3;

    cout<<"Addition is:"<<add<int>(i,j)<<endl;
    cout<<"Addition is:"<<add<float>(n,m);

    return 0;
}