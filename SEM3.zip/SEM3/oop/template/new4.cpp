#include<iostream>
using namespace std;

int main()
{
    int *pointint=new int;
    float *pointfloat=new float;

    *pointint=45;
    *pointfloat=75.5;

    cout<<*pointint<<endl;
    cout<<*pointfloat;

    delete pointint;
    delete pointfloat;

    return 0;
}