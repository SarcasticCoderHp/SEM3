#include<iostream>
using namespace std;

template<typename T>

void Swap(T &a,T &b)
{
    T temp=a;
    a=b;
    b=temp;
}

int main()
{
    int f1=1,f2=2;
    float n1=1.5,n2=2.5;
    char c1='a',c2='b';

    cout<<"Before Swapping:"<<endl;
    cout<<f1<<" "<<f2<<endl;
    cout<<n1<<" "<<n2<<endl;
    cout<<c1<<" "<<c2<<endl;

    Swap(f1,f2);
    Swap(n1,n2);
    Swap(c1,c2);

    cout<<"After Swapping:"<<endl;
    cout<<f1<<" "<<f2<<endl;
    cout<<n1<<" "<<n2<<endl;
    cout<<c1<<" "<<c2<<endl;

    return 0;
}