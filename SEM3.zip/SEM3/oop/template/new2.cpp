#include<iostream>
using namespace std;

template<class T>
class x
{
    public:

    T val;

    void getdata()
    {
       cout<<"Enter value:";cin>>val;
    }
    void display()
    {
        cout<<endl<<val<<endl;
    }
};
int main()
{
    x<int>x1;
    x1.getdata();
    x1.display();

    x<char>x2;
    x2.getdata();
    x2.display();

    x<float>x3;
    x3.getdata();
    x3.display();

   
    return 0;
}
