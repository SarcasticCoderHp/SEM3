#include<iostream>
using namespace std;

template<class T>
class A
{
    T a,b;

    public:

    A(T x,T y)
    {
        a=x;
        b=y;
    }
    void display()
    {
        cout<<"A is:"<<a<<endl;
        cout<<"B is:"<<b;
    }
};

int main()
{
 A<int>a1(1,2);
 a1.display();

 cout<<endl;

 A<double>b1(2.2,5.5);
 b1.display();

 cout<<endl;

 A<char>c1('A','B');
 c1.display();

 cout<<endl;

 return 0;
}