#include<iostream>
using namespace std;

template<class T>
void Swap(T &n1,T &n2)
{
    T temp;
    temp=n1;
    n1=n2;
    n2=temp;
}

int main()
{
    int i1,i2;
    float f1,f2;

    cout<<"Enter value of i1 and i2:";cin>>i1>>i2;
    cout<<"Before swapping value of i1 and i2:"<<i1<<" "<<i2<<endl;
    Swap(i1,i2);
    cout<<"After swapping value of i1 and i2:"<<i1<<" "<<i2<<endl;

    cout<<endl;

    cout<<"Enter value of f1 and f2:";cin>>f1>>f2;
    cout<<"Before swapping value of f1 and f2:"<<f1<<" "<<f2<<endl;
    Swap(f1,f2);
    cout<<"After swapping value of f1 and f2:"<<f1<<" "<<f2<<endl;

    return 0;
}