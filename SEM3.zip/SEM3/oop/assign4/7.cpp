#include<iostream>
using namespace std;

template<class T>T Max(T a,T b)
{
    return(a>b)?a:b;
    
}

int main()
{
    int i,j;
    double x,y;
    char m,n;

    cout<<"Enter value of i and j:";cin>>i>>j;
    cout<<"Maximum is:"<<Max(i,j)<<endl;

    cout<<endl;

    cout<<"Enter value of x and y:";cin>>x>>y;
    cout<<"Maximum is:"<<Max(x,y)<<endl;

    cout<<endl;

    cout<<"Enter value of m and n:";cin>>m>>n;
    cout<<"Maximum is:"<<Max(m,n)<<endl;

    return 0;

}