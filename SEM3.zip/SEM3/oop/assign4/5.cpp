#include<iostream>
using namespace std;

template<class T>
class X
{
    public:
    int n1;
    float n2;
};
int main()
{
       X<int>myobj1;
       X<float>myobj2;

       cout<<"Enter member 1:";cin>>myobj1.n1;
       cout<<"Enter member 2:";cin>>myobj2.n2;   

       cout<<"Member 1 is:"<<myobj1.n1<<endl;
       cout<<"Member 2 is:"<<myobj2.n2;

       return 0;
}