#include<iostream>
using namespace std;

template<class T>T Max(T arr[],int size)
{                           
    T a=arr[0];

    for(int i=0;i<size;i++)
    {
        if(arr[i]>a)
        {
            a=arr[i];
        }
    }    
    return a;
}
int main()
{
    int size;

    cout<<"Enter size of array:";cin>>size;

    int arr[size];

    cout<<"Enter array elements:";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    } 

int max=Max(arr,size);

cout<<"Maximum value is:"<<max<<endl;

return 0;
}