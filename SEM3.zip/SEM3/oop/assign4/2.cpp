#include<iostream>
using namespace std;

template<class T>T add(T a,T b)
{
    return a+b;
}
int main()
{
    int a,b;
    float c,d;

    cout<<"Enter value of a and b:";cin>>a>>b;
    int sum=add(a,b);
    cout<<"Addition is:"<<sum<<endl;

    cout<<"Enter value of c and d:";cin>>c>>d;
    float Sum=add(c,d);
    cout<<"Addition is:"<<Sum<<endl;

    return 0;
}