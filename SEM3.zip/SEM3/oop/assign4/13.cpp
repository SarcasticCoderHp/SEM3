#include<iostream>
using namespace std;

template<class T>
T sarea(T &s1)
{
    return s1*s1;
}

template<class T>
T rarea(T &s1, T &s2)
{
    return s1*s2;
}

template<class T>
T carea(T &s1)
{
    return 3.14*s1*s1;
}

int main()
{

   int s1;
   cout<<"Enter the side:";cin>>s1;
   cout<<"Area of square is:"<<sarea(s1)<<endl;

   int length,width;
   cout<<"Enter length and width:";cin>>length>>width;
   cout<<"Area of rectangle is:"<<rarea(length,width)<<endl;

   int radius;
   cout<<"Enter radius:";cin>>radius;
   cout<<"Area of circle is:"<<carea(radius);

   return 0;
}