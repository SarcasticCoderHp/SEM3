#include<iostream>
using namespace std;

template<class T>T Rev(T num)
{
    T r=0;

    while(num>0)
    {
        r=r*10+num%10;
        num=num/10;
    }
    return r;
}
int main()
{
    int num;
    cout<<"Enter a number:";cin>>num;

    int reverse=Rev(num);

    cout<<"Reversed number is:"<<reverse<<endl;

    return 0;
}