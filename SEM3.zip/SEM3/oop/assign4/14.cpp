#include<iostream>
using namespace std;

template<class T,class T1,class T2>
class Student
{
    private:
    
    T rollno;
    T1 name;
    T2 grade;

    public:

    Student(T rollno,T1 name,T2 grade)
    {
         this->rollno=rollno;
         this->name=name;
         this->grade=grade;
    }
    
    void get()
    {
        cout<<"Enter roll no:";cin>>rollno;
        cout<<"Enter name:";cin>>name;
        cout<<"Enter grade;";cin>>grade;
    }
    void show()
    {
        cout<<"Rollno is:"<<rollno<<endl;
        cout<<"Name is:"<<name<<endl;
        cout<<"Grade is:"<<grade<<endl;
    }
};
int main()
{
    int rollno;
    string name;
    string grade;

    Student<int,string,string>obj(rollno,name,grade);

    cout<<"Student Details...."<<endl;
    obj.get();
    obj.show();

    return 0;
}