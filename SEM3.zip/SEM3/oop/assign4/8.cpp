#include<iostream>
using namespace std;

template<class T>
class display
{
    private:
    T data;

    public:
    display(T value)
    {
        data=value;
    }
    void show()
    {
        cout<<"Value is:"<<data<<endl;
    }
    
};
int main()
{
    int a;
    float b;
    char c;

    cout<<"Enter value of a:";cin>>a;
    cout<<"Enter value of b:";cin>>b;
    cout<<"Enter value of c:";cin>>c;

    display<int>intdisp(a);
    display<float>floatdisp(b);
    display<char>chardisp(c);

    intdisp.show();
    floatdisp.show();
    chardisp.show();

    return 0;
}

