#include<iostream>
using namespace std;

template<class T>
class SI
{
    public:
     
    T calc(T p,T r,T n)
    {
        return (p*r*n)/100;
    }
};
int main()
{
    SI<int>count1;
    SI<float>count2;

    int p,r,n;
    float p1,r1,n1;

        cout<<"Enter value of p:";cin>>p;
        cout<<"Enter value of r:";cin>>r;
        cout<<"Enter value of n:";cin>>n;

        int simple1=count1.calc(p,r,n);
        cout<<"Simple interest is:"<<simple1<<endl;

        cout<<endl;

        cout<<"Enter value of p:";cin>>p1;
        cout<<"Enter value of r:";cin>>r1;
        cout<<"Enter value of n:";cin>>n1;

        float simple2=count2.calc(p1,r1,n1);
        cout<<"Simple interest is:"<<simple2<<endl;

        return 0;

}