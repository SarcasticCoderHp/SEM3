#include<iostream>
using namespace std;

template<class T>
class Binary
{
public:
	T a[20];
	T r;
	T n;

	void get()
	{
		for(int i=0; n>0; i++){
			r=n%2;
			a[i]=r;
			n=n/2;
		}
	}
	void display(){
		cout<<"Binary of n:"<<endl;
		for(int i=i-1;i>=0;i--){
			cout<<a[i];
		}

	}
};
int main(){
	int n;
	cout<<"Enter a value:"<<endl;
	cin>>n;

	Binary<int>b1;
	b1.get();
	b1.display();

	return 0;
}