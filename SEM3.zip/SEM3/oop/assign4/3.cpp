#include<iostream>
using namespace std;

template<class T>
class Array
{

public:

    T a[5];

    void get()
    {
        cout<<"Enter 5 array elements:";
        for(int i=0;i<5;i++)
        {
            cin>>a[i];
        }
    }
    void display()
    {
        cout<<"Array elements are:\n";
        for(int i=0;i<5;i++)
        {
            cout<<a[i]<<endl;
        }
    }
};
int main()
{
    Array<int>obj1;

    obj1.get();
    obj1.display();

    return 0;
}