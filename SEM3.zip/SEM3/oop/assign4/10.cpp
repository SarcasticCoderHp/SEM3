#include<iostream>
using namespace std;

class X
{
    public:

    template<class T>
    void show(T value);
};

template<class T>
void X::show(T value)
{
    cout<<"Value is:"<<value<<endl;
}

int main()
{
    X obj1,obj2;
    int a;
    float b;

    cout<<"Enter value of a:";cin>>a;
    cout<<"Enter value of b:";cin>>b;

    obj1.show(a);
    obj2.show(b);

    return 0;

}