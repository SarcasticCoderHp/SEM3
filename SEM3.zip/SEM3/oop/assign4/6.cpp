#include<iostream>
using namespace std;

template<class T>
class A
{
    public:

    T add(T n1,T n2)
    {
        return n1+n2;
    }

    T sub(T n1,T n2)
    {
        return n1-n2;
    }

    T mul(T n1,T n2)
    {
        return n1*n2;
    }

    T div(T n1,T n2)
    {
        return n1/n2;
    }
};
int main()
{
    int a,b;
    cout<<"Enter value of a and b:";cin>>a>>b;

    A<int>cal;

    cout<<"Addition is:"<<cal.add(a,b)<<endl;
    cout<<"Subtraction is:"<<cal.sub(a,b)<<endl;
    cout<<"Multiplication is:"<<cal.mul(a,b)<<endl;
    cout<<"Division is:"<<cal.div(a,b);

    return 0;
}