#include<iostream>
using namespace std;

int main()
{
        int choice,a,b,add,sub,mul,div;
             
             cout<<"Enter first number";cin>>a;
             cout<<"Enter second number";cin>>b;

             cout<<"1.Addition";
              cout<<"\n";
             cout<<"2.Subtraction";
              cout<<"\n";
             cout<<"3.Multiplication";
              cout<<"\n";
             cout<<"4.Division";
               cout<<"\n";
            cout<<"Enter your choice";cin>>choice;

       switch(choice)
       {
         case 1:
         cout<<"Addition is "<<(a+b);
         break;

        case 2:
         cout<<"Subtraction is "<<(a-b);
         break;

        case 3:
         cout<<"Multiplication is "<<(a*b);
         break;

        case 4:
         cout<<"Division is "<<(a/b);
         break;

         default:
         cout<<"Invalid choice";

       }

    return 0;
}