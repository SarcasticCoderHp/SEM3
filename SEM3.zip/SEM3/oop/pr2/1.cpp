#include<iostream>
using namespace std;

int main()
{
    float a,b,c,per;
    
    cout<<"Enter subject 1 marks";cin>>a    ;
    cout<<"Enter subject 2 marks";cin>>b;
    cout<<"Enter subject 3 marks";cin>>c;

    per=(a+b+c)*100/300;

    if(per>85)
    {
        cout<<"Grade is A+";
    }
   else if(per<85&&per>=75)
   {
    cout<<"Grade is A";
   }
   else if(per<75&&per>=65)
   {
    cout<<"Grade is B";
   }
   else if(per<65&&per>=50)
   {
    cout<<"Grade is C";
   }
   else
   {
    cout<<"You are Fail";
   }

    return 0;
}