#include <iostream>
using namespace std;

int main() {
    int choice;
    double base, height, radius;
    
    cout<<"Area of different shapes:"<<"\n";
do{
    cout << "1. Rectangle\n";
    cout << "2. Circle\n";
    cout << "3. Triangle\n";
    cout << "4. Square\n";
    cout << "5. Exit\n";
    
    cout << "Enter your choice: ";
    cin >> choice;

   
    if (choice == 1) {
        cout << "Enter the length of the rectangle: ";
        cin >> base;
        cout << "Enter the width of the rectangle: ";
        cin >> height;
        cout << "Area of rectangle: " << (base * height) << "\n";
    }
    else if (choice == 2) {
        cout << "Enter the radius of the circle: ";
        cin >> radius;
        cout << "Area of circle: " << (3.14159 * radius * radius) << "\n";
    }
    else if (choice == 3) {
        cout << "Enter the base of the triangle: ";
        cin >> base;
        cout << "Enter the height of the triangle: ";
        cin >> height;
        cout << "Area of triangle: " << (0.5 * base * height) << "\n";
    }
    else if (choice == 4) {
        cout << "Enter the length of the square: ";
        cin >> base;
        cout << "Area of square: " << (base * base) << "\n";
    }
    else if (choice == 5) {
        cout << "Program exited..\n";
    }
    else {
        cout << "Invalid choice.\n";
    }
  }while(choice!=5);
    
    return 0;
}
