#include <iostream>

using namespace std;

int main() {
    int choice, number;

    cout << "Enter a number: ";
    cin >> number;


    cout << "1. Print Multiplication Table\n";
    cout << "2. Check Number is Prime or Not\n";
    cout << "3. Check Number is Odd or Even\n";
    cout << "4. Check Number is Multiply by 7 and 9\n";
    
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
      
        case 1:
            for (int i = 1; i <= 10; i++)
                cout << number << " * " << i << " = " << (number * i) << '\n';
            break;
        case 2:
            if (number <= 1) {
                cout << number << " is not a prime number.\n";
            } else {
                int isPrime = true;
                for (int i = 2; i <= number / 2; ++i) {
                    if (number % i == 0) {
                        cout << number << " is not a prime number.\n";
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime) {
                    cout << number << " is a prime number.\n";
                }
            }
            break;
        case 3:
            cout << number << (number % 2 == 0 ? " is an even number.\n" : " is an odd number.\n");
            break;
        case 4:
            cout << number << (number % 7 == 0 && number % 9 == 0 ? " is divisible by 7 and 9.\n" : " is not divisible by 7 and 9.\n");
            break;
        default:
            cout << "Invalid choice.\n";
            break;
    }

    return 0;
}
