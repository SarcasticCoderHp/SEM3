#include<iostream>
using namespace std;

double power(double m,int n=2)
{
    return m*=n;
    n--;
}
int main()
{
    double base;int exponent;

    cout<<"Enter the base and exponent is default=2:";cin>>base;
    double ans=power(base,exponent);

    cout<<"Result is:"<<ans<<endl;

    double square=power(base);
    cout<<"Square is:"<<square<<endl;

    return 0;
}