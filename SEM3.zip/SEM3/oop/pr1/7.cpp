#include<iostream>
using namespace std;

int main()
{
     
     float u,a,t,final;

       cout<<"Enter velocity";cin>>u;
       cout<<"Enter acceleration";cin>>a;
       cout<<"Enter time";cin>>t;

       final=u+(a*t);

       cout<<"The final velocity is "<<final;

       return 0;
   }