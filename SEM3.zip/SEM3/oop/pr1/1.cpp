#include<iostream>
using namespace std;

int main()
{
  cout<<"HELLO WORLD";

  return 0;
}