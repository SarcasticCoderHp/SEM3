#include<iostream>
using namespace std;

int main()
{
        
  float area,peri,length,width;

  cout<<"Enter the length";cin>>length;
  cout<<"Enter the width";cin>>width;

  peri=2*(length+width);
  area=length*width;

   cout<<"Perimeter of rectangle is "<<peri;
   cout<<"\n";
   cout<<"Area of rectangle is "<<area;

	return 0;
}