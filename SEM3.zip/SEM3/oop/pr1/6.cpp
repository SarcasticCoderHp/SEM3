#include<iostream>
using namespace std;

int main()
{
     
     float p,r,n,interest;

       cout<<"Enter principle";cin>>p;
       cout<<"Enter rate";cin>>r;
       cout<<"Enter time";cin>>n;

       interest=(p*r*n)/100;

       cout<<"Simple interest of given values is "<<interest;

       return 0;
   }