#include<iostream>
using namespace std;

int main()
{
     
     int a,b,sum,sub,mul,div;

     cout<<"Enter value of a";cin>>a;
     cout<<"Enter value of b";cin>>b;

     cout<<a;
     cout<<"\n";
     cout<<b;
 
 return 0;
}