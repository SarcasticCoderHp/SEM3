#include<iostream>
using namespace std;

int main()
{
        
  float area,r;

  cout<<"Enter radius of circle";cin>>r;

  area=3.14*r*r;

  cout<<"Area of circle is "<<area;

  return 0;
}