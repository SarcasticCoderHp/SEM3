#include<iostream>
using namespace std;

int main()
{
     
     int a,b,sum,sub,mul,div;

     cout<<"Enter value of a";cin>>a;
     cout<<"Enter value of b";cin>>b;

     sum=a+b;
     sub=a-b;
     mul=a*b;
     div=a/b;

     cout<<"Addition of both is "<<sum;
       cout<<"\n";
     cout<<"Subtraction of both is "<<sub;
       cout<<"\n";
     cout<<"Multiplication of both is "<<mul;
       cout<<"\n";
     cout<<"Division of both is "<<div;


	return 0;
}