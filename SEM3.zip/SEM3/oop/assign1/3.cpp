#include<iostream>
using namespace std;

int main()
{
    char grade;
    int gradepoints;

    cout<<"Enter a grade:";cin>>grade;

    switch(grade)
    {
        case 'A':
        gradepoints=10;
        break;
        
        case 'B':
        gradepoints=8;
        break;

        case 'C':
        gradepoints=5;
        break;

        case 'D':
        gradepoints=2;
        break;

        default:
        gradepoints=0;
    }
    cout<<"Your grade is:"<<grade<<endl;
    cout<<"Your grade points are:"<<gradepoints<<endl;
    return 0;
}