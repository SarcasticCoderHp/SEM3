#include<iostream>
using namespace std;

int main()
{
    float salary,incometax,netsalary;

    cout<<"Enter salary:";cin>>salary;

    if(salary>30000)
    {
        incometax=salary* 20/100;
    }
    else if(salary>=20000)
    {
        incometax=salary* 15/100;
    }
    else{
        incometax=salary* 10/100;;
    }
    netsalary=salary-incometax;

    cout<<"Net salary is:"<<netsalary<<endl;
    cout<<"Income tax pay is:"<<incometax<<endl;

    return 0;
}