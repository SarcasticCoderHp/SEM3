#include<iostream>
using namespace std;

int main()
{
    int a,b,max;

    cout<<"Enter a and b:";cin>>a>>b;

    max=(a>b)?a:b;

    cout<<"Greatest is:"<<max;

    return 0;
}