#include<iostream>
using namespace std;

int main()
{
    int a,b,c,d,e,sum;
    float per;

    cout<<"Enter 5 marks:";cin>>a>>b>>c>>d>>e;

    sum=a+b+c+d+e;

    per=(sum*100)/500;

    cout<<"Percentage is:%"<<per;

    return 0;
}