#include<iostream>
using namespace std;

int main()
{
    int years, weeks, remainingDays,days;
    
    cout << "Enter the number of days: ";
    cin >> days;

    years = days / 365;
    remainingDays = days % 365;
    weeks = remainingDays / 7;

    cout << "Years: " << years << endl;
    cout << "Weeks: " << weeks << endl;

    return 0;
}

