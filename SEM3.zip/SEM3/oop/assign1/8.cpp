#include<iostream>
using namespace std;

int main()
{
    int a,b,c;

    cout<<"Enter three numbers";cin>>a>>b>>c;

    if(a>b)
    {
        cout<<"Maximum is:"<<a;
    }
    else if(b>c)
    {
        cout<<"Maximum is:"<<b;
    }
    else
    {
        cout<<"Maximum is:"<<c;
    }
    return 0;
}