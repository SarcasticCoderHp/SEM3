#include<iostream>
using namespace std;

int main()
{
    int add,sub,mul,div,mod;
    int a,b;

    cout<<"Enter two numbers:";cin>>a>>b;

    add=a+b;
    sub=a-b;
    mul=a*b;
    div=a/b;
    mod=a%b;

    cout<<"Addition is:"<<add<<endl;
    cout<<"Subtraction is:"<<sub<<endl;
    cout<<"Multiplication is:"<<mul<<endl;
    cout<<"Division is:"<<div<<endl;
    cout<<"Remainder is:"<<mod;

    return 0;
}




