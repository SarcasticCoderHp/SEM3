#include<iostream>
using namespace std;

int main()
{
    int a,b,temp=0;

    cout<<"Enter value of a:";cin>>a;
    cout<<"Enter value of b:";cin>>b;

    cout<<"Before swap value of a:"<<a<<endl;
    cout<<"Before swap value of b:"<<b<<endl;

    temp=a;
    a=b;
    b=temp;

    cout<<"After swap value of a:"<<a<<endl;
    cout<<"After swap value of b:"<<b;

    return 0;
}