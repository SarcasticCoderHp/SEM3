#include<iostream>
using namespace std;

template<class T>void Min(T arr[],int n)
{
    T Min=arr[0];
    for(int i=0;i<n;i++)
    {
        if(arr[i]<Min)
        Min=arr[i];
    }
    cout<<"Minimum element is:"<<Min<<endl;
}

int main()
{
    int a[5];
    double b[5];
    char c[5];

    for(int i=0;i<5;i++)
    {
        cout<<"Enter array elements:";cin>>a[i];
    }
    Min(a,5);

     for(int i=0;i<5;i++)
    {
        cout<<"Enter array elements:";cin>>b[i];
    }
    Min(b,5);

     for(int i=0;i<5;i++)
    {
        cout<<"Enter array elements:";cin>>c[i];
    }
    Min(c,5);

    return 0;
}