#include<iostream>
#include<cstring>
using namespace std;

int main()
{
   int choice;

   cout<<"1.Compare two strings"<<endl;
   cout<<"2.Concate two strings"<<endl;
   cout<<"3.Copy the string"<<endl;
   cout<<"4.Length of string"<<endl;
   cout<<"5.Find no. of words and characters"<<endl;

   cout<<"Enter a choice:";cin>>choice;

   if(choice==1)
   {
     char str1[100];
    char str2[100];

    cout<<"Enter string1:";cin>>str1;
    cout<<"Enter string2:";cin>>str2;

    int result=strcmp(str1,str2);

    if(result==0)
    {
        cout<<"Equal strings";
    }
    else
    {
        cout<<"Not equal strings";
    }
   }

   else if(choice==2)
   {
    char str1[100];
    char str2[100];

    cout<<"Enter string1:";cin>>str1;
    cout<<"Enter string2:";cin>>str2;

    strcat(str1,str2);

    cout<<"Concatenated String:"<<str1<<endl;
   }

   else if(choice==3)
   {
      char str1[100];
    char str2[100];

    cout<<"Enter string1:";cin>>str1;

    strcpy(str2,str1);

    cout<<"Copied String:"<<str2<<endl;
   }

   else if(choice==4)
   {
     char str[100];

    cout<<"Enter string1:";cin>>str;

    cout<<"Length of string:"<<strlen(str);
   }

   else if(choice==5)
   {
     char str[100];
    int word=1;
    int count=0;

    cout<<"Enter a sentance:";cin>>str;

for(int i=0;str[i]!='\0';i++)
{
    if(str[i]==' ')
    
        word++;
}
    cout<<"No of words:"<<word<<endl;
    cout<<"No of characters:"<<count;

   }
             return 0;
}