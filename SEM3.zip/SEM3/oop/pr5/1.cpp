#include<iostream>
using namespace std;

void Sortarr(int arr[],int size)
{
    for(int i=0;i<size;i++)
    {
        int min=i;
        for(int j=0;j<size;j++)
        {
            if(arr[j]<arr[min])
            {
                min=j;
            }
        }
        int temp=arr[i];
        arr[i]=arr[min];
        arr[min]=temp;
    }
}

void Printarr(int arr[],int size)
{
    cout<<"Sorted array is:";
    for(int i=0;i<size;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int main()
{
    int size;
    cout<<"Enter size:";cin>>size;

    int arr[size];

    cout<<"Enter array elements:";
    for(int i=0;i<size;i++)
    {
        cin>>arr[i];
    }

    Sortarr(arr,size);
    Printarr(arr,size);

    return 0;

}