#include<iostream>
using namespace std;

template<class T>T Max(T a,T b)
{
    if(a>b)
    return a;
    else
    return b;
}
int main()
{
    int i=5; int j=10;
    float m=3; float n=9;

    cout<<"Largest number is:"<<Max<int>(i,j)<<endl;
    cout<<"Largest number is:"<<Max<float>(m,n);

    return 0;

}