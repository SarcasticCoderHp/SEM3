#include<iostream>
using namespace std;

inline int Check(int a)
{
    return a>0;
}
int main()
{
    int a;
    cout<<"Enter a number:";cin>>a;

    if(Check(a))
    {
        cout<<"Number is positive";
    }
    else 
    {
        cout<<"Number is negative";
    }
    return 0;
}