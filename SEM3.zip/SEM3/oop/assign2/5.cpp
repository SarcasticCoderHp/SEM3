#include<iostream>
using namespace std;

class Currency
{

    public:

    float amount;
    float paise;

    Currency(float a,float p)
    {
        amount=a;
        paise=p;
    }
    Currency Add(Currency other)
    {
        return Currency(amount+other.amount,paise+other.paise);
    }
};
int main()
{
    float amount1,amount2;
    float paise1,paise2;

    cout<<"Enter first currency details:"<<endl;
    cout<<"Enter amount:";cin>>amount1;
    cout<<"Enter paise:";cin>>paise1;
    Currency currency1(amount1,paise1);

    cout<<endl;

    cout<<"Enter second currency details:"<<endl;
    cout<<"Enter amount:";cin>>amount2;
    cout<<"Enter paise:";cin>>paise2;
    Currency currency2(amount2,paise2);

    cout<<endl;

    Currency result=currency1.Add(currency2);

    cout<<"Details after adding currency:"<<endl;
    cout<<"Rupees:"<<result.amount<<endl;
    cout<<"Paise:"<<result.paise;

    return 0;

}