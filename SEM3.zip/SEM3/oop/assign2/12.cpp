#include<iostream>
using namespace std;

class Swap {
private:
    int num1;
    int num2;

public:
    Swap(int n1, int n2)
    {
        num1=n1;
        num2=n2;
    }

    friend void swapNumbers(Swap& a);

    void display() {
        cout << "Numbers before swapping:" << num1 << " " << num2 << endl;
    }
    void show()
    {
       cout << "Numbers after swapping:" << num1 << " " << num2 << endl;   
    }

};
void swapNumbers(Swap& a) {
    int temp = a.num1;
    a.num1 = a.num2;
    a.num2 = temp;
}

int main() {
    int num1, num2;
    cout << "Enter two numbers: ";
    cin >> num1 >> num2;

    Swap a(num1, num2);

    a.display();

    swapNumbers(a);

    a.show();

    return 0;
}
