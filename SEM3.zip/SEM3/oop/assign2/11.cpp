#include<iostream>
using namespace std;

int check(int x,float y)
{
    return x+y;
}
int check(float x,int y)
{
   return x-y;
}
int main()
{
    cout<<check(10,50.5)<<endl;
    cout<<check(50.5,10);

    return 0;
}