#include<iostream>
using namespace std;

class Employee
{
    public:

    int id;
    string name;
    float salary;

    void getdata()
    {
        cout<<"Enter the id:";cin>>id;
        cout<<"Enter the name:";cin>>name;
        cout<<"Enter the salary:";cin>>salary;
    }
    
    void display()
    {
        cout<<"Id"<<id<<endl<<"Name:"<<name<<endl<<"Salary:"<<salary<<endl;
    }
};

int main()
{
    Employee e1;

    e1.getdata();
    e1.display();

    return 0;
}