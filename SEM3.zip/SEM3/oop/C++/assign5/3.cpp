#include<iostream>
using namespace std;

int main()
{
    int arr[5];
    int index;

    cout<<"Enter 5 array elements:";
    for(int i=0;i<5;i++)
    {
        cin>>arr[i];
    }

    cout<<"Enter array index:";cin>>index;

    try
    {
        if(int ele=arr[index])
        {
          cout<<"Value at index is:"<<ele<<endl;
        }
        else
        {
            throw index;
        }
    }
        catch(int index)
        {
            cout<<"Array index out of bound";
        }
    
        return 0;
}