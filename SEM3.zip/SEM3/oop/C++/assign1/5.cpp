#include<iostream>
using namespace std;

void find(int days)
{
    int years, weeks, remainingDays;

    years = days / 365;
    remainingDays = days % 365;
    weeks = remainingDays / 7;

    cout << "Years: " << years << endl;
    cout << "Weeks: " << weeks << endl;
}

int main()
{
    int days;
    cout << "Enter the number of days: ";
    cin >> days;

    find(days);

    return 0;
}
