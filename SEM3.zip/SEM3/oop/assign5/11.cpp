#include<iostream>
using namespace std;

int main()
{
    string str;
    cout<<"Enter a string:";
    getline(cin,str);

    try 
    {
        int isVowel=false;

        for(char c:str)
        {
            if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='A' || c=='E' || c=='I' || c=='O' || c=='U')
            {
                isVowel=true;
                break;
            }
        }
        if(!isVowel)
        {
            throw str;
        }
        else
    {
        cout<<"String has vowels";
    }
    
    }
    catch(string str)
    {
         cout<<"Vowels not found";
    }
    return 0;
}