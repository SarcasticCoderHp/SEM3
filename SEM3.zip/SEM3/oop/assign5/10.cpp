#include<iostream>
using namespace std;

void check(int num)
{
    if(num%2!=0)
    {
       throw num;
    }
}

int main()
{
    int num;
    cout<<"Enter a number:";cin>>num;

    try
    {
        check(num);
        cout<<"Number is even"<<endl;
    }
    catch(int num)
    {
        cout<<"Number is odd";
    }
    return 0;
}