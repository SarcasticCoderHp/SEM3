#include<iostream>
using namespace std;

int main()
{
	char email[50];

	cout<<"Enter email address:";cin>>email;

	try
	{
        for(int i=0;i<50;i++)
        {
		if(email[i]=='@')
		{
			throw email[i];
		}
	}
		cout<<"Not a Valid email address...";
	}
	catch(char email)
	{
		cout<<"Valid email address"<<endl;
	}
	return 0;
}