#include<iostream>
using namespace std;

int main()
{
    int numerator,denominator,div;

    cout<<"Enter numerator:";cin>>numerator;
    cout<<"Enter denominator:";cin>>denominator;

    try
    {
      if(denominator==0)
      {
         cout<<"Denominator cant be zero"<<endl;
        throw denominator;
       
      }
      else
      {
            div=numerator/denominator;
            cout<<"Division is:"<<div<<endl;
      }
    }
    catch(int denominator)
    {
        cout<<"Enter denominator again:";cin>>denominator;

        div=numerator/denominator;

        cout<<"Division is:"<<div<<endl;
    }
    return 0;
}
       