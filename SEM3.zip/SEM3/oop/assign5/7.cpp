#include<iostream>
using namespace std;

int main()
{
    int acc_no,balance,withdraw_amt;

    cout<<"Enter account number:";cin>>acc_no;
    cout<<"Enter current balance:";cin>>balance;

    while(true)
    {
         cout<<"Enter withdrawal amount:";cin>>withdraw_amt;

        try
        {
            if(withdraw_amt>balance)
            {
                cout<<"Invalid amount"<<endl;
                throw withdraw_amt;
            }
            else {cout<<"Transaction done"<<endl;
            break;
            }
    }
    
    catch(int withdraw_amt)
    {
      cout<<"Enter amount less than balance"<<endl;
    }
    }
    return 0;
}