#include<iostream>
using namespace std;

int main()
{
    int a;
    cout<<"Enter value of a:";cin>>a;

  try
  {
        switch(a)
        {
            case 1:
            throw 'a';
            break;

            case 2:
            throw 1;
            break;

            case 3:
            throw 4.781;
            break;

            default:
            throw "Exeption occured";
        }
  }

  catch(char a)
  {
    cout<<"Exeption handled..char";
  }
  catch(int a)
  {
    cout<<"Exeption handled...int";
  }
  catch(double a)
  {
    cout<<"Exeption handled...double";
  }
  return 0;

}