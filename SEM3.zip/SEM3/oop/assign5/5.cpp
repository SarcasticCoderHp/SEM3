#include<iostream>
using namespace std;

int main()
{
    try{
    int num1,num2,result;
    char op;

    cout<<"Enter a number:";cin>>num1;

    cout<<"Enter a operator to perform:";cin>>op;

    if(op!='+' && op!='-' && op!='*' && op!='/')
    {
        throw op;
    } 

    cout<<"Enter second number:";cin>>num2;

        switch(op)
        {
            case '+':
            result=num1+num2;
            break;

            case '-':
            result=num1-num2;
            break;

            case '*':
            result=num1*num2;
            break;

            case '/':
            try{
            if(num2!=0)
            {
            result=num1/num2;
            break;
            }
            else
            {
                throw num2;
            }
            }
            catch(int num2)
            {
                cout<<"Denominator cant be zero"<<endl;
            }

            default:
            cout<<"Invalid operation"<<endl;
        }
        cout<<"Result is:"<<result<<endl;
    }
catch(char op)
{
    cout<<"Invalid operator....."<<endl;
}
return 0;
}