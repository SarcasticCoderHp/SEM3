#include<iostream>
using namespace std;

int main()
{
    int age;
    cout<<"Enter the age:";cin>>age;

    try
    {
        if(age<18)
        {
            throw age;
        }
        else
        {
            cout<<"Valid for license";
        }
    }
    catch(int age)
    {
        cout<<"Age not enough for license";
    }
    return 0;
}