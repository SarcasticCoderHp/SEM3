#include<iostream>
using namespace std;

int main()
{
    int n;
  
   cout<<"Enter no of integers:";cin>>n;

    try
    {
         if(n<=1)
         {
            throw n;
         }

        int num,high=0,second=0;

        for(int i=0;i<n;i++)
        {
            cout<<"Enter numbers:";cin>>num;

            if(num>high)
            {
                second=high;
                high=num;
            }
            else if(num>second && num!=high)
            {
                second=num;
            }
        }
        cout<<"Highest Number:"<<high<<endl;
        cout<<"Secong highest Number:"<<second<<endl;
    }
    catch(int n)
    {
        cout<<"Enter atleast two numbers";
    }   
    return 0;
    }
