#include<iostream>
using namespace std;

int main()
{
    int num;

    cout<<"Enter a number(>0 and <100):";cin>>num;

    try
    {
      if(num<=0 || num>=100)
      {
        throw num;
      }

      else{
        cout<<"Number is:"<<num<<endl;
        } 
    }
    catch(int num)
    {
        cout<<"Exeption occured";
    }
    return 0;
}