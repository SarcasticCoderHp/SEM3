#include<iostream>
using namespace std;

int main()
{
    int num,r,sum=0;

    cout<<"Enter a number:";cin>>num;
    int temp=num;


        while(num>0)
        {
            r=num%10;
            sum=sum+r*r*r;
            num=num/10;
        }
        try
        {
            if(temp!=sum)
            {
                throw num;
            }
            else
            {
                cout<<"It is armstrong number"<<endl;
            }
        }
        catch(int num)
        {
            cout<<"Number is not armstrong number"<<endl;
        }
        return 0;
}