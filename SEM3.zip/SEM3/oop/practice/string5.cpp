#include<iostream>
using namespace std;

int main()
{
    string str="C PROGRAMMING";

    cout<<str<<endl;
    
    str.resize(9);

    cout<<str;
    return 0;
}