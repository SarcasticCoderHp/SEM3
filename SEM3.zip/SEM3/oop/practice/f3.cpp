#include<iostream>
using namespace std;

int sum()
{
    int a,b,sum;
    cout<<"Enter value of a:";cin>>a;
    cout<<"Enter value of b:";cin>>b;

    sum=a+b;
    return sum;
}
int main()
{
    int result;
    result=sum();
    cout<<"Sum of numbers:"<<result;
    return 0;
}