#include<iostream>
using namespace std;

class Demo
{
    private:
    int a,square;

    public:
    void setA(int x)
    {
        a=x;
        square=a*a;
    }
    friend void printresult(Demo);
};
void printresult(Demo d)
{
    d.a=10;
    cout<<"Square of number is:"<<d.square;
}
int main()
{
    Demo d;
    d.setA(5);
    printresult(d);
    return 0;
}