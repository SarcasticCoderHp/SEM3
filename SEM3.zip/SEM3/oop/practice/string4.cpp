#include<iostream>
using namespace std;

int main()
{
    string s1="HELLO";
    string s2="WORLD";

    s1.append(s2);

    cout<<s1;
    return 0;

}
