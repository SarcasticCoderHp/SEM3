#include<iostream>
using namespace std;

class add
{
    public:

    void display(int a,float b)
    {
         cout<<endl<<a<<" "<<b<<" "<<endl;
    }
    void display(float a,int b)
    {
        cout<<endl<<a<<" "<<b<<" "<<endl;
    }
};
int main()
{
    add obj;

    obj.display(50,100.7);
    obj.display(75.5,50);

    return 0;
}