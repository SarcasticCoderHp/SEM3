#include<iostream>
using namespace std;

int main()
{
    double a[]={1,2,3,4,5};
    double sum=0;
    double count =0;
    double average;

    for(int i=0;i<5;i++)
    {
        cout<<a[i]<<" "<<endl;
        sum=sum+a[i];
        count++;
    }
    cout<<"Sum is:"<<sum<<endl;
    average=sum/count;
    cout<<"Average is:"<<average<<endl;

    return 0;
}