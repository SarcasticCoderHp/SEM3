#include<iostream>
using namespace std;

int demofunc(int i)
{
    return i;
}
double demofunc(double d)
{
    return d;
}
int main()
{
    cout<<demofunc(100)<<endl;
    cout<<demofunc(500.5);

    return 0;
}