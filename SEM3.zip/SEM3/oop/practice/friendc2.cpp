#include<iostream>
using namespace std;

class Demo
{
    private:
    int a,square;

    public:
    friend void printresult();
};
void printresult()
{
  Demo d;
  d.a=5;
  d.square=d.a*d.a;
  cout<<"Square is:"<<d.square;
}
int main()
{
    Demo d;
    printresult();
    return 0;
}