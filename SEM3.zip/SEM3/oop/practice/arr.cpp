#include<iostream>
using namespace std;

int main()
{
  int a[10],i,j,temp,n;
  cout<<"Enter size of array:";cin>>n;

  for(int i=0;i<n;i++)
  {
     cout<<"Enter array elements:";cin>>a[i];
  }
  for(int i=0;i<n;i++)
  {
    for(int j=i+1;j<n;j++)
    {
        if(a[i]>a[j])
        {
            temp=a[i];
            a[i]=a[j];
            a[j]=temp;
        }
    }
  }
  for(int i=0;i<n;i++)
  
    cout<<a[i]<<endl;
    return 0;
  
  
}