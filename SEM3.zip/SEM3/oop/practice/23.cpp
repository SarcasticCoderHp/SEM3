#include<iostream>
using namespace std;

class Demo
{
    private:
      int a;

      public:

      friend void display(Demo);
};
void display(Demo d)
{
    d.a=10;
    cout<<"a is:"<<d.a<<endl;
}
int main()
{
    Demo d;
    display(d);
    return 0;
}