#include<iostream>
using namespace std;

class Employee
{
    public:

    int id;
    string name;
    float salary;

    void getdata(int i,string n,float s)
    {
        this->id=i;
        this->name=n;
        this->salary=s;
    }
    void display()
    {
        cout<<id<<" "<<endl<<name<<" "<<endl<<salary<<" "<<endl;
    }
};
int main()
{
    Employee e1;

    e1.getdata(101,"ABC",5000.57);
    e1.display();

    return 0;
}
