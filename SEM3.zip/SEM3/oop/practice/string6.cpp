#include<iostream>
using namespace std;

int main()
{
    string f1="Mango";
    string f2="Kiwi";

    cout<<"F1 before swap:"<<f1<<endl;
    cout<<"F2 before swap:"<<f2<<endl;
 
    f1.swap(f2);

    cout<<endl;

    cout<<"F1 after swap:"<<f1<<endl;
    cout<<"F1 after swap:"<<f2<<endl;

         return 0;

}