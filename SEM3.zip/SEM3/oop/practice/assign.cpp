#include<iostream>
using namespace std;

class BankAccount{
    
    private:

    int accountNumber;
    string name;
    float balance;

    public:

     BankAccount(int accNum,string accName,double accBal)
     {
        accountNumber=accNum;
        name=accName;
        balance=accBal;
     }
     void deposit(double amount)
     {
        balance+=amount;
     }
     void withdraw(double amount)
     {
        if(amount>balance)
        {
            cout<<"Balance is not sufficient";
        }
        else
        {
            balance-=amount;
            cout<<"Withdrawn:"<<amount<<endl;
            cout<<"Remaining balance:"<<balance;
        }
     }
     double getBalance()
     {
        return balance;
     }
};

int main()
{
    int accNum;
    string accName;
    double accBal;

    for(int i=0;i<=3;i++)
    {
        cout<<"Enter account number:";cin>>accNum;
        cout<<"Enter holder name:";cin>>accName;
        cout<<"Enter initial balance:";cin>>accBal;

        BankAccount account(accNum,accName,accBal);

        double depositAmount,withdrawAmount;

        cout<<"Enter amount to deposit:";cin>>depositAmount;
        account.deposit(depositAmount);

        cout<<"Enter amount to withdraw:";cin>>withdrawAmount;
        account.withdraw(withdrawAmount);
    }
    return 0;
}