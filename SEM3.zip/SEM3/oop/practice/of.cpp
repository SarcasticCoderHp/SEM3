#include<iostream>
using namespace std;

class Example
{
    public:
           int a;
    void add(Example e)
    {
        a=a+e.a;
    }
};
int main()
{
    Example e1,e2;

    e1.a=50;
    e2.a=100;

    cout<<"Value 1:"<<e1.a<<endl;
    cout<<"Value 2:"<<e2.a<<endl;

    e2.add(e1);
    e1.add(e2);

    cout<<"Value 1 after:"<<e1.a<<endl;
    cout<<"Value 2 after:"<<e2.a;

    return 0;
}