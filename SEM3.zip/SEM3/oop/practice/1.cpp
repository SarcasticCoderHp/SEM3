#include<iostream> 
using namespace std;

void sum()
{
    int a,b,sum;

    cout<<"Enter a and b:";cin>>a>>b;
    sum=a+b;

    cout<<"Sum is:"<<sum;
}
int main()
{
    sum();
    return 0;
}