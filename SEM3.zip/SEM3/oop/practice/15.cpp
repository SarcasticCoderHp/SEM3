#include<iostream>
using namespace std;

class Example
{
    public:
    int a;

    void add(Example E)
    {
        this->a=this->a+E.a;
    }
};
int main()
{
    Example E1,E2;

    E1.a=50;
    E2.a=100;

    cout<<"Value 1:"<<E1.a<<endl;
    cout<<"Value 2:"<<E2.a;

    E2.add(E1);
    E1.add(E2);

     cout<<"Value 1:"<<E1.a<<endl;
    cout<<"Value 2:"<<E2.a;

    return 0;
}