#include<iostream>
using namespace std;

class Employee
{
    public:

    int id;
    string name;
    float salary;

    void getdata(int id,string name,float salary)
    {
        this->id=id;
        this->name=name;
        this->salary=salary;
    }
    void display()
    {
        cout<<id<<" "<<endl<<name<<" "<<endl<<salary<<" ";
    }
};
int main()
{
    Employee e1;

    e1.getdata(1,"ABC",19500.5);
    e1.display();

    return 0;
}