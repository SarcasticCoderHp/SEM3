#include<iostream>
using namespace std;

void add(int a,int b)
{
    int sum;
    sum=a+b;

   cout<<"Sum is:"<<sum;
}
int main()
{
    int a,b;
    cout<<"Enter a and b:";cin>>a>>b;

    add(a,b);
    return 0;
}