#include<iostream>
using namespace std;

class A
{
    public:

    int i;

    void getdata(int i)
    {
        this->i=i;
    }
};
int main()
{
    A a1,a2;

    int x=10;
    a1.getdata(x);
    cout<<x;
    
    cout<<"\n";

    a2.getdata(x);
    cout<<x;

    return 0;
}