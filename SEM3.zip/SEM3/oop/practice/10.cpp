#include<iostream>
using namespace std;

class Demo
{
    public:

    int demofunction(int i)
{
    return i;
}
double demofunction(double d)
{
    return d;
}
};
int main()
{
    Demo obj;

    cout<<obj.demofunction(150)<<endl;
    cout<<obj.demofunction(121.345);

    return 0;
}