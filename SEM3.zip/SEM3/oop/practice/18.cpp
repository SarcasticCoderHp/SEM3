#include<iostream>
using namespace std;

class Myclass
{
    public:

    Myclass()
    {
        cout<<"Hello world";
    }
};
int main()
{
    Myclass obj;
    return 0;
}
