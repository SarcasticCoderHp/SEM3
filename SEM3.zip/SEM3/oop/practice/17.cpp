#include<iostream>
using namespace std;

class Example
{
    public:
     int a;

     Example compare(Example E)
     {
        if(E.a>a)
          return E;
          else
          return *this;
     }
};
int main()
{
    Example E1,E2;

    E1.a=500;
    E2.a=300;

    Example E3;

    E3=E2.compare(E1);

    cout<<E3.a;

    return 0;
}