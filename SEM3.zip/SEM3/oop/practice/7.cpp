#include<iostream>
using namespace std;

void func(int=10,int=20);

int main()
{
    func(50,50);
}
void func(int i,int j)
{
    int z;
    z=i+j;
    cout<<z;
}