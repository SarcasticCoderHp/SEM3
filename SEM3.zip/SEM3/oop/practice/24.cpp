#include<iostream>
using namespace std;

class Demo
{
private:
int a,square;

public:
friend void display();
};
void display()
{
    Demo d;
    d.a=5;
    d.square=d.a*d.a;
    cout<<"Square is:"<<d.square<<endl;
}
int main()
{
    Demo d;
    display();
    return 0;
}
