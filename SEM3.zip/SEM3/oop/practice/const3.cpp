#include<iostream>
using namespace std;

class Employee
{
    public:

    int id;
    string name;
    float salary;

    Employee(int id,string name,float salary)
    {
         id;
         name;
         salary;
    }
void display()
{
    cout<<e1.id<<" "<<endl<<e1.name<<" "<<endl<<e1.salary<<" "<<endl;
}
};

int main()
{
    Employee e1,e2;

    e1.display();
    e2.display();

    return 0;
}