#include<iostream>
using namespace std;

class Employee
{
    public:

    Employee()
    {
        cout<<"This is constructor"<<endl;
    }
};
int main()
{
    Employee e1,e2;
    return 0;
}