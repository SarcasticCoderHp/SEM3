#include<iostream>
using namespace std;

int demofunction(int i)
{
    return i;
}
double demofunction(double d)
{
    return d;
}
int main()
{
    cout<<demofunction(100)<<endl;
    cout<<demofunction(500.567);

    return 0;
}