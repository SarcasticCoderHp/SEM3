#include<iostream>
using namespace std;

void add(int a,int b)
{
    int c=a+b;
    cout<<"Sum of numbers:"<<c;
}
int main()
{
    int x,y;
    cout<<"Enter value of x";cin>>x;
    cout<<"Enter value of y";cin>>y;

    add(x,y);

    return 0;
}