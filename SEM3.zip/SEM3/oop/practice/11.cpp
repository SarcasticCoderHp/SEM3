#include<iostream>
using namespace std;

class Add
{
    public:

    int add(int a,int b)
    {
        return a+b;
    }
    int add(int a,int b,int c)
    {
        return a+b+c;
    }
};
int main()
{
    Add obj;

    cout<<obj.add(10,20)<<endl;
    cout<<obj.add(10,10,10);

    return 0;

}