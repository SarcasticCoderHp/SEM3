#include<iostream>
using namespace std;

class Demo
{
    private:

    int a,square;

    friend class Test;
};
class Test
{
    public:
    void display(Demo d)
    {
        d.a=10;
        d.square=d.a*d.a;
        cout<<"Square is:"<<d.square<<endl;
    }
};
int main()
{
    Demo d;
    Test t;
    
    t.display(d);
    return 0;
}