#include<iostream>
using namespace std;

int main()
{
    string str="C Programming";
    cout<<"Length of string is:"<<str.length()<<endl;
    cout<<"Cpacity of string is:"<<str.capacity();
    return 0;

}