#include<iostream>
using namespace std;

void func(int=10,int=20);

int main()
{
    func(100);
    cout<<"\n";
    func(50,200);
    cout<<"\n";
    func(500.5);
    cout<<"\n";
    func();
}
void func(int i,int j)
{
    int z;
    z=i+j;
    cout<<"Sum is:"<<z;
}
