#include<iostream>
using namespace std;

int sum(int a,int b)
{
    int sum;
    sum=a+b;
    return sum;
}
int main()
{
    int a,b,result;

    cout<<"Enter a and b:";cin>>a>>b;

    result=sum(a,b);

    cout<<"Sum is:"<<result;

    return 0;
}