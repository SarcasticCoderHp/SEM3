#include<iostream>
using namespace std;

int sum()
{
    int a,b,sum;

    cout<<"Enter a and b:";cin>>a>>b;

    sum=a+b;
    return sum;
}
int main()
{
    int result;

    result=sum();

    cout<<"Sum is:"<<result;
}