#include<iostream>
using namespace std;

void display(int m[5])
{
    cout<<"Displaying marks:"<<endl;

    for(int i=0;i<5;i++)
    {
        cout<<"Student"<<i+1<<" "<<m[i]<<endl;
    }
}
int main()
{
    int marks[5]={10,20,30,40,50};
    display(marks);
    return 0;
}