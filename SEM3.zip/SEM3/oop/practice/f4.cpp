#include<iostream>
using namespace std;

int sum(int a,int b)
{
    int x,y,sum;
    cout<<"Enter value of x:";cin>>x;
    cout<<"Enter value of y:";cin>>y;

    sum=x+y;
    return sum;
}
int main()
{
    int result;
    result=sum(a,b);
    cout<<"Sum of numbers:"<<result;
    return 0;
}