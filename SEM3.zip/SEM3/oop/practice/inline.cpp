#include<iostream>
using namespace std;

inline int Max(int x,int y)
{
    return (x>y)?x:y;
}
int main()
{
    cout<<"Max is:"<<Max(5,10)<<endl;
    cout<<"Max is:"<<Max(20,50);

    return 0;
    
}