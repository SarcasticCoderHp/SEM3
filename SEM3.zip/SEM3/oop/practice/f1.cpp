#include<iostream>
using namespace std;

void add()
{
    int a,b;
    cout<<"Enter value of a";cin>>a;
    cout<<"Enter value of b";cin>>b;

    int sum=a+b;
    cout<<"Sum of numbers:"<<sum;
}
int main()
{
    add();
    return 0;
}