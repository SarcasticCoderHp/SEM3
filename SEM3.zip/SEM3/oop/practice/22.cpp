#include<iostream>
using namespace std;

class A
{
    public:

    int i,j;

    A(A &x)
    {
        i=x.i;
        j=x.j;
    }
    A()
    {
        i=10;j=20;
    }
};
int main()
{
    A a1;
    A a2(a1);

    cout<<a2.i<<" "<<a2.j;
    return 0;
}