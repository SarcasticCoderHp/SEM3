#include<iostream>
using namespace std;

int main()
{
    string str1="HELLO WORLD";
    char str2[10];

    str1.copy(str2,5,6);
    str2[9]='\0';

    cout<<"Copied String:"<<str2;
    return 0;

}
