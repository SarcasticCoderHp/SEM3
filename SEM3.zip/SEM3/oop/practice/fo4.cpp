#include<iostream>
using namespace std;

class add
{
   public:

   void display(int a,float b)
   {
    cout<<endl<<a<<" "<<b;
   }
   void display(float a,int b)
   {
    cout<<endl<<a<<" "<<b;
   }
};
int main()
{
    add obj;

    obj.display(20,15.5);
    obj.display(15.5,20);

    return 0;
}