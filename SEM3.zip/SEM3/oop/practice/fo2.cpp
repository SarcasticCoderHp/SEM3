#include<iostream>
using namespace std;

class Democlass
{
    public:
    int demofunc(int i)
    {
        return i;
    }
    double demofunc(double d)
    {
        return d;
    }
};
int main()
{
    Democlass obj;

    cout<<obj.demofunc(100)<<endl;
    cout<<obj.demofunc(500.5);

    return 0;
}