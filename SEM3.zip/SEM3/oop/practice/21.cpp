#include<iostream>
using namespace std;

class Student
{
    private:

    int no;
    double fee;

    public:

     Student(int,double);

     Student(Student &t)
     {
        no=t.no;
        fee=t.fee;
     }

Student::Student(int n,double f)
{
    no=n;
    fee=f;
}
void Student::display()
{
    cout<<endl<<no<<" "<<endl<<fee<<" "<<endl;
}
};
int main()
{
    Student s(1001,10000);
    s.display();

    return 0;
}
