#include<iostream>
using namespace std;

class Demo
{
    private:
    int a;

    public:
    friend void printresult(Demo);
};
void printresult(Demo d)
{
    d.a=10;
    cout<<"a is:"<<d.a;
}
int main()
{
    Demo d;
    printresult(d);
    return 0;
}