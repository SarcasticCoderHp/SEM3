#include<iostream>
using namespace std;

class Employee
{
    public:

    Employee()
    {
        cout<<"Default constructor"<<endl;
    }
};
int main()
{
    Employee e1,e2;
    return 0;
}