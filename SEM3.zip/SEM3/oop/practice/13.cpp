#include<iostream>
using namespace std;

class  A
{
    public:
     int i;

    void getdata(int i)
    {
        this->i=i;
    }
    void display()
    {
        cout<<"value:"<<i<<endl;
    }
};
int main()
{
    A a1;
    int x=10;
    int y=20;

    a1.getdata(x);
    a1.display();

    A a2;
    a2.getdata(y);
    a2.display();

    return 0;

}