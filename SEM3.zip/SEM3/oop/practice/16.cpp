#include<iostream>
using namespace std;

class Example
{
    public:

    int a;

    Example add(Example E1,Example E2)
    {
        E2.a=E1.a+E2.a;
        return E2;
    }
    
};

int main()
{

    Example E1,E2;

    E1.a=50;
    E2.a=100;

    cout<<"Value 1:"<<E1.a<<endl;
    cout<<"Value 2:"<<E2.a;

    Example E3;

    E3=E2.add(E1);

    return 0;

}