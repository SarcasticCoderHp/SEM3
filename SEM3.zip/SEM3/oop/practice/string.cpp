#include<iostream>
using namespace std;

int main()
{
    string str="length";
    cout<<"Length of string:"<<str.length();
    return 0;
}