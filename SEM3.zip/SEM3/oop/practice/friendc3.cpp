#include<iostream>
using namespace std;

class Demo{
    
    private:
    int a,square;
    
    public:
     void setA(int x)
    {
        a=x;
        square=a*a;
    }
    friend class Test;
};
class Test
{
    public:
    void printresult(Demo d)
    {
        cout<<"Square is:"<<d.square;
    }
};
int main()
{
    Demo d;
    Test t;
    class Test;
    d.setA(5);
    t.printresult(d);
    return 0;
}