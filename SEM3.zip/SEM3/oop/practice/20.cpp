#include<iostream>
using namespace std;

class Employee
{
    public:
    int id;
    string name;
    float salary;

    Employee(int i,string n,float s)
    {
        id=i;
        name=n;
        salary=s;
    }
    void display()
{
    cout<<id<<" "<<endl<<name<<" "<<endl<<salary<<" "<<endl;
}
};

int main()
{
   Employee e1=Employee(1,"ABC",5000.98);
   cout<<endl;
   Employee e2=Employee(2,"DEF",7800.56);

   e1.display();
   e2.display();

   return 0;
}