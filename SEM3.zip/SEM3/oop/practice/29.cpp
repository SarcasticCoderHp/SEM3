#include<iostream>
using namespace std;

int*display(int*m)
{
    for(int i=0;i<5;i++)
    {
        cout<<"Student"<<i+1<<" "<<m[i]<<endl;
    }
    return m;
}
int main()
{
     int marks[5]={10,20,30,40,50};
     int*m1;
     m1=display(marks);
     return 0;
}